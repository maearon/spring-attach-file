#!/bin/bash
echo "Deploying to Vercel..."
vercel deploy --prod

package com.example.springboilerplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringboilerplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
